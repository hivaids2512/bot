# facebook-chat-bot

This is a simple chat bot for facebook meesenger.
